package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;
@Entity
@Table(name = "customerspring")
@Component
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE , generator = "myseq")
    @SequenceGenerator(name = "myseq" , sequenceName = "customerspringseq" , 
    initialValue = 3000 ,allocationSize = 1)
    @Column(length = 10)
	private int custId;
	@NotBlank(message = "username cannot blank")
    @Column(length = 20)
	private String username;
	@NotBlank(message = "password must be entered")
	//@Pattern(regexp = "^[a-zA-Z0-9]{6}$", message = "password must have alphanumeric ")
    @Column(length = 20)
	private String password;
	@NotNull(message = "must enter age ")
	@Min(value = 18, message = "age should be > 18")
    @Column(length = 20)
	private Integer age;
	@NotEmpty(message = "must enter mail")
	@Email(message = "Invalid email")
    @Column(length = 30)
	private String email;
	@NotNull(message = "provide phone number")
	//@Pattern(regexp = "[0-9]{10}", message = "phone number invalid")
    @Column(length = 10)
	private Long phone;
    @Column(length = 10)
	private String address;
    @Column(length = 10)
	private String gender;
    @Column(length = 10)
	private String role;
	

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public String getRole() {
		return role;
	}



	public void setRole(String role) {
		this.role = role;
	}



	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getPhone() {
		return phone;
	}

	public void setPhone(Long phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", username=" + username + ", password=" + password + ", age=" + age
				+ ", email=" + email + ", phone=" + phone + ", address=" + address + ", gender=" + gender + "]";
	}


}
