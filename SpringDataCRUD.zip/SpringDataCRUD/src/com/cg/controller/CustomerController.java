package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.beans.Customer;
import com.cg.beans.Gender;
import com.cg.dao.CustomerRepositry;

@Controller
public class CustomerController {
	@Autowired
	Customer customer ;
	@Autowired
	CustomerRepositry customerRepository;
	
	@RequestMapping("/")
	public ModelAndView first() {
		ModelAndView modelView = new ModelAndView();
		modelView.setViewName("login");
		return modelView;
	}
	
	@RequestMapping("/registerlink")
	public String registerlink(ModelMap map) {
		map.addAttribute(customer);
		return "register";
	}
	
	@RequestMapping("/register")
	public ModelAndView register(@Valid Customer customer , BindingResult errors) {
		ModelAndView modelView = new ModelAndView();
		if(errors.hasErrors()) {
			modelView.setViewName("register");
			modelView.addObject("status","Not Registered try again");
		}else {
			customerRepository.save(customer);
			modelView.setViewName("login");
			modelView.addObject("status" , "Registered Successfully");
			
		}
		return modelView;
	}
	
	@RequestMapping(value = "/loginvalidation" , method = RequestMethod.POST)
	public ModelAndView validate(@RequestParam String username , @RequestParam String password,HttpServletRequest request) {
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		customer = customerRepository.validate(username  , password);
		if(customer != null){
			if(customer.getRole().equalsIgnoreCase("admin")) {
				modelView.setViewName("adminhome");
			}else {
			session.setAttribute("customer" , customer);
			modelView.setViewName("customerhomepage");
			}
		}else {
			modelView.addObject("status" , "Invalid username/password");
			modelView.setViewName("login");
		}
		return modelView;
	}
	
	@ModelAttribute("genderList")
	public List<Gender> populate(){
		
		ArrayList<Gender> list = new ArrayList<>();
		Gender g1 = new Gender();
		g1.setType("Male");
		Gender g2 = new Gender();
		g2.setType("Female");
		list.add(g1);
		list.add(g2);
		return list;
	}
	
	@RequestMapping("/viewprofile")
	public String viewprofile()
	{
		return "customerhomepage";
	}
	
	@RequestMapping("/updateprofile")
	public String updateptrofile(ModelMap map , HttpServletRequest request)
	{
		customer =(Customer) request.getSession().getAttribute("customer");
		map.addAttribute(customer);
		return "update";
	}
	
	@RequestMapping("/updatedata")
	public ModelAndView updatedata(@Valid Customer customer , BindingResult errors) {
		ModelAndView modelView = new ModelAndView();
		if(errors.hasErrors()) {
			modelView.setViewName("register");
			modelView.addObject("status","Not updated try again");
		}else {
			customerRepository.save(customer);
			modelView.setViewName("login");
			modelView.addObject("status" , "updated Successfully");
			
		}
		return modelView;
	}
	
	@RequestMapping("/viewById")
	public String getbyId() {
		return "viewById";
	}
	
	@RequestMapping("/viewAll")
	public ModelAndView viewAll() {
		ModelAndView modelView = new ModelAndView();
		List<Customer> customerList = customerRepository.findAll();
		modelView.addObject("customerList" , customerList);
		modelView.setViewName("adminhome");
		
		return modelView;
	}
	

	@RequestMapping("/delete")
	public ModelAndView delete(@RequestParam Integer custId) {
		ModelAndView modelAndView = new ModelAndView();
customerRepository.deleteById(custId);
	 customer=customerRepository.findById(custId).get();
	 
		if (customer==null) {
			modelAndView.addObject("status", "deleted successfully");

		} else
			modelAndView.addObject("status", "not deleted");
		modelAndView.setViewName("adminhome");
		return modelAndView;
	} 
 


	@RequestMapping(value = "/viewCustomer")
	public ModelAndView viewCustomer(@RequestParam Integer custId) {
		ModelAndView modelAndView = new ModelAndView();
		Customer customer = customerRepository.findById(custId).get();
		modelAndView.addObject("customer" , customer);
		modelAndView.setViewName("viewById");
		
		return modelAndView;
	}
}
