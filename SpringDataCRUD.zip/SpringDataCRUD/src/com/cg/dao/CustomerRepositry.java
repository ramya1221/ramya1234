package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.beans.Customer;
@Repository
public interface CustomerRepositry extends JpaRepository<Customer, Integer> {
	
	@Query("select c from Customer c where c.username=?1 and c.password=?2")
	 Customer validate(String username , String password);
    
List<Customer> findByAddress(String address);
	

}
