package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.beans.Product;
import com.cg.dao.ProductRepository;
@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepository productRepository;
@Transactional
	@Override
	public Product addProduct(Product p) {
		return productRepository.save(p) ;
	}
@Transactional
	@Override
	public void deleteById(String id) {
		productRepository.deleteById(id);
	}
@Transactional
	@Override
	public Product updateProduct(Product p) {
	return productRepository.save(p);
	}
@Transactional
	@Override
	public List<Product> getProducts() {
		return productRepository.findAll();
	}
@Transactional
	@Override
	public Product findById(String id) {
	return productRepository.findById(id).get();
	}
	

}
