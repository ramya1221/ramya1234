package com.cg.beans.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.beans.Customer;

public class  CustomerDao{
	EntityManager entityManager;
 EntityManagerFactory  entityManagerFactory;
 EntityTransaction entityTransaction;
 
public CustomerDao()
 {

		entityManagerFactory=
				Persistence.createEntityManagerFactory("jpa");
		 entityManager=entityManagerFactory.createEntityManager();
		entityTransaction =entityManager.getTransaction();

 }
 public void addCustomer(Customer c)
 {
		entityTransaction.begin();
		 entityManager.persist(c);
		 entityTransaction.commit();
		
		 
 }

public List<Customer> getCustomer() 
{
	TypedQuery<Customer> query= entityManager.createQuery("select c from Customer c",Customer.class);
	List<Customer> customerList=query.getResultList();
	return customerList;
}
public boolean updateCustomer(Customer c) {
	entityTransaction.begin();

	Query query=entityManager.createQuery(
			"update Customer c set c.email=?1,c.phone=?2 where c.name=?3 ");
	query.setParameter(1, c.getEmail());
	query.setParameter(2, c.getPhone());
	query.setParameter(3, c.getName());

	int row=query.executeUpdate();
	entityTransaction.commit();
	if(row>0) {
		return true;
	}else return false;
	}

public List<Customer> ascendingOrder(){
	
	TypedQuery<Customer> query=
			entityManager.createNamedQuery("orderbyname",Customer.class);
	List<Customer> customerList=query.getResultList();
	return customerList;
}

public Customer getByName(String name) {
	TypedQuery<Customer> query=entityManager.
			createNamedQuery("findbyname",Customer.class);
	query.setParameter("name", name);
	Customer customer= query.getSingleResult();
	return customer;
}
public List<Customer> getWithStartletter(char c){
	
	TypedQuery<Customer> query=
			entityManager.createNamedQuery("startwithletter",Customer.class);
query.setParameter(1, c + "%");
List<Customer> custList=query.getResultList();
	return custList;
}




}





