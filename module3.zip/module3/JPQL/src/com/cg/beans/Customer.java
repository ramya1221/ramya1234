package com.cg.beans;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@NamedQueries({
@NamedQuery(name="orderbyname",
query="select c from Customer c order by c.name"),
@NamedQuery(name="findbyname",
query="select c from Customer c where c.name=:name"),
@NamedQuery(name="startwithletter",
query="select c from Customer c where c.name like ?1")

})
@Entity
@Table(name="customerdata")
public class Customer implements Serializable {
private static final long  serialVersionUID =1L;
 
 
 @Id
 @GeneratedValue(strategy =GenerationType.SEQUENCE,generator="mysql")
 @SequenceGenerator(name="myseq", sequenceName= "customerdata1", initialValue =1000,allocationSize =1)
 @Column(name ="id",length=5)
 
 
 
 private int custid;
@Column(length=20,nullable=false)
	private String name;
 @Column(length =25,nullable=false,unique=true)
 private String email;
 @Column(name="mobile",nullable=false, unique=true,length=10)
 private long phone;
 
 

public Customer(String name, String email, long phone) {
	super();

	this.name = name;
	this.email = email;
	this.phone = phone;
}

public Customer() {
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "\n" + custid + "\t" + name + "\t" + email + "\t" + phone;
}

public int getCustid() {
	return custid;
}

public void setCustid(int custid) {
	this.custid = custid;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public long getPhone() {
	return phone;
}

public void setPhone(long phone) {
	this.phone = phone;
}
                                                               
 

 
}

