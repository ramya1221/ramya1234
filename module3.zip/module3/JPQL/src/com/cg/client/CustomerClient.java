package com.cg.client;

import java.util.List;
import java.util.Scanner;

import com.cg.beans.Customer;
import com.cg.beans.dao.CustomerDao;


public class CustomerClient {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
	   CustomerDao customerDao = new CustomerDao();
		String option = null;
		do {
			System.out.println("enter choice \n1.Add \n2.viewAll \n3.order \n4.findByname \n5.firstletter \n6.Update");
			int choice = scanner.nextInt();
			switch (choice) {

			case 1: {
				System.out.println("enter name ,email,phone");
				String name = scanner.next();
				String email = scanner.next();
				long phone = scanner.nextLong();
				Customer c = new Customer(name, email, phone);
				customerDao.addCustomer(c);

			}
				break;
			case 2: {
				List<Customer> custList = customerDao.getCustomer();
				for (Customer customer : custList) {
					System.out.println(customer);
				}
			}
				break;

			case 3: {
				List<Customer> custList = customerDao.ascendingOrder();
				for (Customer customer : custList) {
					System.out.println(customer);
				}
			}
				break;

			case 4: {
				System.out.println("enter name:");
				String name = scanner.next();
				Customer cust = customerDao.getByName(name);
				System.out.println(cust);
			}
				break;

			case 5: {
				System.out.println("enter first letter of name");
				char c = scanner.next().charAt(0);
				List<Customer> custList = customerDao.getWithStartletter(c);
				for (Customer customer : custList) {
					System.out.println(customer);
				}
			}
				break;
			case 6: {
				System.out.println("enter name to change");
				String name = scanner.next();
				Customer customer = customerDao.getByName(name);
				System.out.println("enter email to change");
				String mail = scanner.next();

				customer.setEmail(mail);
				System.out.println("enter phone to change");
				customer.setPhone(scanner.nextLong());
				

				boolean result = customerDao.updateCustomer(customer);
				customer.setEmail(scanner.next());

				
				if (result) {
					System.out.println("updated");
				} else {
					System.out.println("not updated");
				}

			}
				break;
			}

			System.out.println("press y to cntinue.....");
			option = scanner.next();
		} while (option.equalsIgnoreCase("y"));

	}

}
