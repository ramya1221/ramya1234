package com.cg.beans;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;


@Entity
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@SequenceGenerator(name="myseq",sequenceName="productseq",
	initialValue=100,allocationSize=1)
	@Column(length=5)
	private int id;
	@Column(length=20)
	private String name;
	@Column(length=10)
	private double price;
	@ManyToMany(mappedBy="products",cascade=CascadeType.ALL)
	private Set<Order> orders=new HashSet<>();
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(String name, double price, Set<Order> orders) {
		super();
		this.name = name;
		this.price = price;
		this.orders = orders;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Set<Order> getOrders() {
		return orders;
	}
	public void setOrders(Set<Order> orders) {
		this.orders = orders;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
}
