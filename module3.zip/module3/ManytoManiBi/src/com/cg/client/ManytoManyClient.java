package com.cg.client;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.beans.Order;
import com.cg.beans.Product;

public class ManytoManyClient {

	public static void main(String[] args) {
		EntityManagerFactory entityFactory=Persistence.createEntityManagerFactory("jpa");
		EntityManager entityManager=entityFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Product p1=new Product();
		p1.setName("mobile");
		p1.setPrice(20000);
		
		Product p2=new Product();
		p2.setName("TV");
		p2.setPrice(22000);
		
		Product p3=new Product();
		p3.setName("lipstick");
		p3.setPrice(2000);
		
		Product p4=new Product();
		p4.setName("pen");
		p4.setPrice(200);
		
		//first Order
		Order monishorder=new Order();
		monishorder.setOrderDate(new Date());
		monishorder.addProduct(p1);
		monishorder.addProduct(p2);
		monishorder.addProduct(p3);
		//second order
		Order balajiorder=new Order();
		balajiorder.setOrderDate(new Date());
		balajiorder.addProduct(p1);
		balajiorder.addProduct(p4);
		
		entityManager.persist(monishorder);
		entityManager.persist(balajiorder);
		transaction.commit();
		System.out.println("Order saved");
	}

}
