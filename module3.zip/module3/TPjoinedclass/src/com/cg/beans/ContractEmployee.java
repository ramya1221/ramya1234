package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "tpjoinedcemp")
@PrimaryKeyJoinColumn(name = "id")

public class ContractEmployee extends Employee {
	@Column(length=8)
	private int dailywages;
	@Column(length=5)
	private int noOfdays;
	public ContractEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ContractEmployee(int dailywages, int noOfdays) {
		super();
		this.dailywages = dailywages;
		this.noOfdays = noOfdays;
	}
	public int getDailywages() {
		return dailywages;
	}
	public void setDailywages(int dailywages) {
		this.dailywages = dailywages;
	}
	public int getNoOfdays() {
		return noOfdays;
	}
	public void setNoOfdays(int noOfdays) {
		this.noOfdays = noOfdays;
	}
	@Override
	public String toString() {
		return "ContractEmployee [dailywages=" + dailywages + ", noOfdays=" + noOfdays + "]";
	}
	
	

}
