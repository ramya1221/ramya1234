package com.cg.beans;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="authorone")
public class Author implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "myseq")
	@SequenceGenerator(name="myseq", sequenceName = "authorseq",initialValue = 100,allocationSize = 1)
	private int Authorid;
	private String name;
	
	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Author( String name) {
		super();
		
		this.name = name;
	}


	public int getAuthorid() {
		return Authorid;
	}

	public void setAuthorid(int authorid) {
		Authorid = authorid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Author [Authorid=" + Authorid + ", name=" + name + "]";
	}
	

}
