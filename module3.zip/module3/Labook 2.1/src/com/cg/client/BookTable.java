package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.beans.Author;
import com.cg.beans.Book;

public class BookTable {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("jpa");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		Author author1=new Author();
		author1.setName("james gosling");
	
		Book book1=new Book();
		book1.setTitle("java");
		book1.setPrice(600);
		book1.setAuthor(author1);
		entityManager.persist(book1);
		
		entityTransaction.commit();
		System.out.println("object saved");

	}

}
