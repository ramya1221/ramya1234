package com.cg.client;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.beans.Department;
import com.cg.beans.Employee;

public class OneToManyClient {
	
	
	public static void main(String[] args) {
		
		
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("jpa");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Employee e1=new Employee("Ramya", 32223.56);
		Employee e2=new Employee("Tanmayee", 42223.56);
		Set<Employee>empset=new HashSet<>();
		empset.add(e1);
		empset.add(e2);
		Department d =new Department("training",empset);
		entityManager.persist(d);
		transaction.commit();
		System.out.println("saved");
		
	}

}
