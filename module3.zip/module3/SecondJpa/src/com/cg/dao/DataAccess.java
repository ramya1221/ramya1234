package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.beans.Employee;

public class DataAccess {

	EntityManagerFactory entityFactory;
	EntityManager entityManager;
	EntityTransaction transaction;

	public DataAccess() {
		entityFactory = Persistence.createEntityManagerFactory("jpa");
		entityManager = entityFactory.createEntityManager();
		transaction = entityManager.getTransaction();
	}

	public void addObj(Employee e) {
		transaction.begin();
		entityManager.persist(e);
		transaction.commit();

	}

	public Employee update(Employee e) {
		transaction.begin();
		Employee updatedEmployee = entityManager.merge(e);
		transaction.commit();
		return updatedEmployee;

	}

	public void deleteEmployee(int id) {
		transaction.begin();
		Employee obj = entityManager.find(Employee.class, id);
		entityManager.remove(obj);
		transaction.commit();

	}

	public List<Employee> viewAll() {

		Query q1 = entityManager.createQuery("from Employee");

		List<Employee> empList = q1.getResultList();
		return empList;
	}

	public Employee viewById(int id) {
		Employee obj = entityManager.find(Employee.class, id);

		return obj;
	}

	@Override
	protected void finalize() throws Throwable {
		entityFactory.close();
		super.finalize();
	}
}
