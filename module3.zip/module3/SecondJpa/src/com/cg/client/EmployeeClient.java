package com.cg.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.beans.Employee;
import com.cg.dao.DataAccess;

public class EmployeeClient {
	public static void main(String[] args) {
		DataAccess daoObject = new DataAccess();
		Scanner scanner = new Scanner(System.in);
		do {
		System.out.println("Which operation do u want perform");
		System.out.println();
		System.out.println("1.Add\n2.Update\n3.Delete\n4.ViewAll\n5.ViewById");
		
		
		int option = scanner.nextInt();
		
		switch(option) {
		case 1:{
			
			System.out.println("Enter Emp Name");
			String name = scanner.next();
			System.out.println("Enter Salry");
		    double salry = scanner.nextDouble();
		    System.out.println("enter designation");
		    String des = scanner.next();
		    Employee emp = new Employee( name ,salry , des);
		    daoObject.addObj(emp);
		    
		    break;
		}
		case 2:{
			System.out.println("Enter id of employee u want to update");
			int getId = scanner.nextInt();
			Employee e = daoObject.viewById(getId);
			System.out.println("you are going to update " + e.getName() + "??");
			System.out.println("Enter y to update");
			String decision = scanner.next();
			
			if(decision.equalsIgnoreCase("y")){
			    System.out.println("What do u want to update");
			    System.out.println("1.salry\n2.designation");
			    int choice = scanner.nextInt();
			    
			    switch(choice) {
			    case 1:{
			    	System.out.println("Enter Salary");
			    	double newSalry = scanner.nextDouble();
			    	e.setSalary(newSalry);
			    	break;
			    }
			    case 2:{
			    	System.out.println("Enter Designation");
			    	String newDesignation = scanner.next();
			    	e.setDesignation(newDesignation);
			    	break;
			    }
			    default:{
			    	System.out.println("Enter only 1 or 2");
			    }
			    }
			    
			    daoObject.update(e);	
			    
			}else {
				break;
			}
			
		}
		case 3:{
			System.out.println("Enter Id of employee you want to delete");
			int delId = scanner.nextInt();
			daoObject.deleteEmployee(delId);
			break;
			
		}
		case 4:{
			List<Employee> list = new ArrayList<Employee>();
			
			list = daoObject.viewAll();
			System.out.println(list);
			break;
			
		}
		case 5:{
			System.out.println("Enter id of employee");
			int getId = scanner.nextInt();
			
			Employee e = daoObject.viewById(getId);
			
			System.out.println(e);
			
			break;
		}
		default:{
			System.out.println("Enter only 1-5");
		}
		}
		
		}while(true);

	}

}
