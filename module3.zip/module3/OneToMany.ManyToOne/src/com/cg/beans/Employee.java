package com.cg.beans;

import java.io.Serializable;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="EMP_DETAIL1")
public class Employee implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "myseq")
	@SequenceGenerator(name="myseq", sequenceName = "empdetailseq", initialValue = 100,allocationSize = 1)
	
	private int id;
	@Column(length = 20)
	String name;
	public Employee( String name, double salary) {
		super();
		
		this.name = name;
		this.salary = salary;
	}


	@Column(precision = 10 ,scale = 2,length = 15)
	private double salary;
	@ManyToOne
	@JoinColumn(name="dept_no")
	private Department department;

	public Department getDepartment() {
		return department;
	}


	public void setDepartment(Department department) {
		this.department = department;
	}


	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}


	public int getEid() {
		return id;
	}


	public void setEid(int eid) {
		this.id = eid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}

}
