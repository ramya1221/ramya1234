package com.cg.client;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.beans.ContractEmployee;
import com.cg.beans.Employee;
import com.cg.beans.PermenentEmployee;

public class TPHClient {

	public static void main(String[] args) {
		EntityManagerFactory entityFactory=Persistence.createEntityManagerFactory("jpa");
		EntityManager entityManager=entityFactory.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Employee emp=new Employee();
		emp.setName("ramya");
		ContractEmployee cemp=new ContractEmployee();
		cemp.setName("tanmayee");
		cemp.setDailywages(5000);
		cemp.setNoOfdays(10);
		
	PermenentEmployee pemp =new PermenentEmployee();
		pemp.setName("divya");
		pemp.setSalary(20000);
		pemp.setBonus(5000);
		entityManager.persist(emp);
		entityManager.persist(cemp);
		entityManager.persist(pemp);
		transaction.commit();
		System.out.println("saved");
	}

}
