package com.cg.beans;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Student implements Serializable {
	private static final long serialVersionUID=1L;
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
@SequenceGenerator(name="myseq",sequenceName="student1",
initialValue=100,allocationSize=1)
private int studId;
private String name;
private double marks;
String domain;

public Student() {
	super();
	// TODO Auto-generated constructor stub
}
public int getStudId() {
	return studId;
}
public void setStudId(int studId) {
	this.studId = studId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getMarks() {
	return marks;
}
public void setMarks(double marks) {
	this.marks = marks;
}
public String getDomain() {
	return domain;
}
public void setDomain(String domain) {
	this.domain = domain;
}
@Override
public String toString() {
	return "\nstudId=" + studId + ", name=" + name + ", marks=" + marks + ", domain=" + domain ;
}

}
