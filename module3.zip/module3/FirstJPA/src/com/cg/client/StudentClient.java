package com.cg.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.cg.beans.Student;
public class StudentClient {
	static EntityManagerFactory entityFactory;
	static EntityManager entityManager;

	public static void main(String[] args) {
	entityFactory=
			Persistence.createEntityManagerFactory("jpa");
entityManager=entityFactory.createEntityManager();
	EntityTransaction transaction=entityManager.getTransaction();
	transaction.begin();
	
	
	/*transaction.begin();
	Student s1=new Student();
	s1.setName("tanmayee");
	s1.setMarks(78);
	s1.setDomain("sql");
	entityManager.persist(s1);*/
	
	Student s=entityManager.find(Student.class, 101);
	s.setName("poo");
	s.setMarks(100);
	System.out.println(update(s));
	
	viewAll();
	System.out.println("Student-100 is:");
	System.out.println(getById(100));
	delete(103);
	transaction.commit();
	System.out.println("object saved");
	entityFactory.close();

	}
static void viewAll()
{
	Query q1=entityManager.createQuery("from Student");
	List<Student> studList=q1.getResultList();
	System.out.println(studList);
}
	
	
	static Student getById(int id) {
		Student s=entityManager.find(Student.class,id);
		return s;
		
	}
	static void delete(int id) {
		Student s=entityManager.find(Student.class,id);
		entityManager.remove(s);
	}
	static Student update(Student s) {
		Student updatedstudent=entityManager.merge(s);
		return updatedstudent;
	}
}