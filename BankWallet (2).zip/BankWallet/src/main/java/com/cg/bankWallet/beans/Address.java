package com.cg.bankWallet.beans;

public class Address {
    String city;
    String state;
    String postalCode;
	public Address() {
		super();
	}
	
	public Address(String city, String state, String postalCode) {
		super();
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
	}

	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", postalCode=" + postalCode + "]";
	}
    
     
}
