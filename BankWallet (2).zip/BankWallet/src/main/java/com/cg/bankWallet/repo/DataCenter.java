package com.cg.bankWallet.repo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.bankWallet.beans.Customer;
import com.cg.bankWallet.beans.Transaction;

public class DataCenter {
	
   public  Map<String , Customer> customers = new HashMap<String, Customer>();
	
	public List<Transaction> list1 = new ArrayList<Transaction>();
    public List<Transaction> list2 = new ArrayList<Transaction>();
	
	public Map<String, List<Transaction>> transactions = new HashMap<String, List<Transaction>>();
	

}
