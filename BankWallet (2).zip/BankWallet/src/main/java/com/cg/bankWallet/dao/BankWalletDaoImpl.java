package com.cg.bankWallet.dao;

import java.util.List;

import com.cg.bankWallet.beans.Customer;
import com.cg.bankWallet.beans.Transaction;
import com.cg.bankWallet.repo.DataCenter;

public class BankWalletDaoImpl implements IBankWalletDao {
    DataCenter dataObject = new DataCenter();
    
	public boolean createAccount(Customer customer) {
		dataObject.customers.put(customer.getMobileNumber(), customer);
		return false;
	}

	public Customer functionalities(String phoneNumber) {
		return dataObject.customers.get(phoneNumber);
	}
	
	public void insertTransactions(Customer customer ,Customer beneficiary ) {
		String mobile =customer.getMobileNumber();
		String beneficiaryNumber = beneficiary.getMobileNumber();
		if(mobile.equals("9550142728")) {
			
			dataObject.list1.add(customer.getTransation());
			dataObject.list2.add(beneficiary.getTransation());
			
			dataObject.transactions.put(mobile , dataObject.list1);
			dataObject.transactions.put(beneficiaryNumber , dataObject.list2);
			
		}
		if(mobile.equals("8328571240")) {
			dataObject.list1.add(beneficiary.getTransation());
			dataObject.list2.add(customer.getTransation());
			
			dataObject.transactions.put(mobile , dataObject.list2);
			dataObject.transactions.put(beneficiaryNumber , dataObject.list1);
		}
		
		
	}
	

	public List<Transaction> viewTransaction(String mobileNumber) {
		
		return dataObject.transactions.get(mobileNumber);
	}

}
