package com.cg.bankWallet.service;

import com.cg.bankWallet.beans.Customer;

public interface IBankWalletService {
	
		boolean createAccount(Customer customer);
		double showBalance(Customer customer);
		boolean withDraw(Customer customer , double amount);
	    boolean fundTransfer(Customer customer , String mobileNumber);
	    void printTransactions(String mobileNumber);
	    double deposit(Customer customer , double amount);

	

}
