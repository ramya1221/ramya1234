package com.cg.bankWallet.beans;

public class Transaction {
	String type;
	private String transactionId;
	String beneficiaryName;
	String accountNumber;
	double amount;
	String date;
	double avlBalance;

	public Transaction() {
		super();
	}

	public Transaction(String type, String transactionId, String beneficiaryName, String accountNumber, double amount,
			String date, double avlBalance) {
		super();
		this.type = type;
		this.transactionId = transactionId;
		this.beneficiaryName = beneficiaryName;
		this.accountNumber = accountNumber;
		this.amount = amount;
		this.date = date;
		this.avlBalance = avlBalance;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	@Override
	public String toString() {
		String finalString;
		if ((this.type).equalsIgnoreCase("credited")) {
			finalString = "\nActionPerformed\t:\t" + type + "\nTransactionId\t:\t" + transactionId
					+ "\nCreditedFrom\t:\t" + beneficiaryName + "\nAccountNumber\t:\t" + accountNumber + "\nAmount\t\t:\t"
					+ amount + "\nDate\t\t:\t" + date + "\nAvailableBal\t:\t" + avlBalance;
		} else {

			finalString = "\nActionPerformed\t:\t" + type + "\nTransactionId\t:\t" + transactionId
					+ "\nTransferedto\t:\t" + beneficiaryName + "\nAccountNumber\t:\t" + accountNumber
					+ "\nAmount\t\t:\t" + amount + "\nDate\t\t:\t" + date + "\nAvailableBal\t:\t" + avlBalance;
		}
		return finalString;
	}

}
