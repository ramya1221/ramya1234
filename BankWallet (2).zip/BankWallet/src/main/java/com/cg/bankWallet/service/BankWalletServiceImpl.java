package com.cg.bankWallet.service;

import java.util.List;
import java.util.Scanner;

import com.cg.bankWallet.beans.Customer;
import com.cg.bankWallet.beans.Transaction;
import com.cg.bankWallet.dao.BankWalletDaoImpl;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BankWalletServiceImpl implements IBankWalletService {
    
	BankWalletDaoImpl dataAccessObject = new BankWalletDaoImpl();
	 
	 Scanner scanner = new Scanner(System.in);
	 
	 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		String date = dtf.format(now);
		
	public Customer retriveRecords(String mobileNumber) {
		
		return dataAccessObject.functionalities(mobileNumber);
	}
	
	public boolean createAccount(Customer customer) {
		dataAccessObject.createAccount(customer);
		return true;
	}

	public double showBalance(Customer customer) {
		
		return customer.getAccount().getBalance();
	}

	public boolean withDraw(Customer customer , double amount) {
		boolean flag = true;
		double accountBalance = customer.getAccount().getBalance();
		if(customer.getAccount().getBalance() < amount) {
			System.out.println("Transaction Failed due to insufficient funds");
			flag = false;
		}
		else {
		     accountBalance -= amount;
		     customer.getAccount().setBalance(accountBalance);
		}
		return flag ;
	}

	public boolean fundTransfer(Customer customer ,String mobileNumber) {
		String transactionId = "TCI0001254";
		int random = (int) (Math.random()*10000);
		transactionId += random;
		boolean flag = false;
		Customer beneficiary = dataAccessObject.functionalities(mobileNumber);
		if(beneficiary != null) {
		System.out.println("Enter Amount to transfer");
		double amount = scanner.nextDouble();
		System.out.println("Enter your password Again");
		String password = scanner.next();
		String original = customer.getPassWord();
		if(original.equals(password)) {
		if(customer.getAccount().getBalance() > amount) {
		double totalBalance = (beneficiary.getAccount().getBalance())+(amount);
		beneficiary.getAccount().setBalance(totalBalance);
		double debitedAmount = ((customer.getAccount().getBalance())-amount);
		customer.getAccount().setBalance(debitedAmount);
		customer.setTransation(new Transaction("debited", transactionId ,
		 beneficiary.getCustomerName(), beneficiary.getAccount().getAccountNumber() , amount, date , debitedAmount));
		beneficiary.setTransation(new Transaction("credited", transactionId ,
				customer.getCustomerName() ,customer.getAccount().getAccountNumber(), amount, date , totalBalance));
		dataAccessObject.insertTransactions(customer , beneficiary);
		flag = true;
		}else {
			System.out.println("Transaction Failed due to insufficient funds");
		}
		}else {
			System.out.println("Invalid password");
			flag = false;
		}
	
		}else {
			System.out.println("There is no customer registered with this number");
		}
		return flag;
		
	}
	
	public double deposit(Customer customer , double amount) {
		boolean flag = false;
		double totalBalance = (customer.getAccount().getBalance()) + amount;
		customer.getAccount().setBalance(totalBalance);
		return customer.getAccount().getBalance();
	}

	public void printTransactions(String mobileNumber) {
		Customer customer = dataAccessObject.functionalities(mobileNumber);
		double avlBalance = customer.getAccount().getBalance();
		
		List<Transaction> transactions = dataAccessObject.viewTransaction(mobileNumber);
		
		for(Transaction transaction : transactions) {
			
			System.out.println(transaction);
		}
		
	}
	
	

}
