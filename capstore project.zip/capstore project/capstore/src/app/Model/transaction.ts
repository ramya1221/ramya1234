import { Order } from './order';
import { ReturnOrders } from './return-orders';
import { GenerateInvoice } from './generate-invoice';
import { RefundMoney } from './refund-money';

export class Transaction {  
 transactionId:Number;
 order:Order;
 amount:Number;
 modeOfPurchase:String;
 status:String;
 transactionDate:String;
 returnOrder:ReturnOrders;
 generateInvoice:GenerateInvoice;
 refundMoney:RefundMoney; 
}
