import { InvoiceProduct } from './invoice-product';
import { Order } from './order';
import { Coupons } from './coupons';
import { Customer } from './customer';
import { Transaction } from './transaction';

export class GenerateInvoice {
     invoiceId:number;
     transaction:Transaction;
    
     customer:Customer;
    

     coupon:Coupons;
    
    
     order:Order;

     invoiceProduct:InvoiceProduct; 
 

}
