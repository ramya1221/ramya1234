import { InvoiceProduct } from './invoice-product';

describe('InvoiceProduct', () => {
  it('should create an instance', () => {
    expect(new InvoiceProduct()).toBeTruthy();
  });
});
