import { RefundMoney } from './refund-money';

describe('RefundMoney', () => {
  it('should create an instance', () => {
    expect(new RefundMoney()).toBeTruthy();
  });
});
