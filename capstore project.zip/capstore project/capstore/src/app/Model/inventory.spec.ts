import { Inventory } from './inventory';

describe('Inventory', () => {
  it('should create an instance', () => {
    expect(new Inventory()).toBeTruthy();
  });
});
