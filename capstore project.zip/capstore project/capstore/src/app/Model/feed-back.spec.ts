import { FeedBack } from './feed-back';

describe('FeedBack', () => {
  it('should create an instance', () => {
    expect(new FeedBack()).toBeTruthy();
  });
});
