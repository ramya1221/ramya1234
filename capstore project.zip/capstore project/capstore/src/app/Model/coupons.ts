import { Inventory } from './inventory';
import { GenerateInvoice } from './generate-invoice';

export class Coupons {
 couponId:Number;
 couponCode:String;
 couponAmount:Number;
 couponDescription:String;
 issueDate:String;
 expiryDate:String;
 inventory:Inventory;
 generateInvoice:GenerateInvoice;  
}
