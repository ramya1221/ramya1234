import { Attraction } from './attraction';

describe('Attraction', () => {
  it('should create an instance', () => {
    expect(new Attraction()).toBeTruthy();
  });
});
