import { Discount } from './discount';
import { Inventory } from './inventory';

export class Category {
    categoryId:Number;
     categoryName:String;
     dis:Discount;
    inventory:Inventory[];
}
