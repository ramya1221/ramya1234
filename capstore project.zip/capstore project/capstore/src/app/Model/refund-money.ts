import { ReturnOrders } from './return-orders';
import { Transaction } from './transaction';
import { BankAccount } from './bank-account';

export class RefundMoney {
 refundId:number;
 returnOrder:ReturnOrders;
 transaction:Transaction;
 bankAccount:BankAccount;
}
