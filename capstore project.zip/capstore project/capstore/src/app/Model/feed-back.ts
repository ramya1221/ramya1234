import { Customer } from './customer';
import { Inventory } from './inventory';
import { Merchant } from './merchant';

export class FeedBack {
     feedBackId:number;	
     customer:Customer;
   inventory:Inventory;		
     merchant:Merchant;
     ProductRating:number;
     comments:String; 
     status:String;

}
