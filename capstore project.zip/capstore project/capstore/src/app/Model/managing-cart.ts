import { Customer } from './customer';
import { Inventory } from './inventory';

export class ManagingCart {
 cartId:number;
 customer:Customer;
 inventory:Inventory;
 quantity:number;
 status:String;
}

