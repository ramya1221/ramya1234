import { Order } from './order';
import { Customer } from './customer';
import { Transaction } from './transaction';
import { Merchant } from './merchant';
import { RefundMoney } from './refund-money';

export class ReturnOrders {
     returnId:number;
	 order:Order;
	 customer:Customer;
	 transaction:Transaction;
	 description:String;
	 returnMode:String;
	 returnDate:String;
	 merchantValidation:String;
	 merchant:Merchant;
	 refundMoney:RefundMoney;
}
