export class Admin {
  	adminId:number;
	email:String;
	password:String;
	lastLogin:String;

}
