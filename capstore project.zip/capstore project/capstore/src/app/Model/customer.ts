import { Address } from './address';
import { Shipping } from './shipping';
import { BankAccount } from './bank-account';
import { ManagingCart } from './managing-cart';
import { Order } from './order';
import { FeedBack } from './feed-back';
import { ReturnOrders } from './return-orders';
import { WishList } from './wish-list';

export class Customer {
     customerId:number
	 customerName:String
	 phoneNumber:String;
	 emailId:String;
	 dateOfBirth:String;
	 password:String;
	 address:Address[];
	 lastLogin:String;
	 isActive:String;
	 shipping:Shipping[];
	 bank:BankAccount[];
	 managingCart:ManagingCart[];
	 order:Order[];
	 feedBack:FeedBack[];
     returnOrders:ReturnOrders[];
	 wishList:WishList[];
	
}
