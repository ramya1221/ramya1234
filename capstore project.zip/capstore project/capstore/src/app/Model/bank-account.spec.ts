import { BankAccount } from './bank-account';

describe('BankAccount', () => {
  it('should create an instance', () => {
    expect(new BankAccount()).toBeTruthy();
  });
});
