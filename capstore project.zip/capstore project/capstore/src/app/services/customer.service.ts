import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../Model/customer';
import { WishList } from '../Model/wish-list';
import { FeedBack } from '../Model/feed-back';
import { Inventory } from '../Model/inventory';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

customerprofileurl:String='/customer/customerprofile';
urlshowproducts:string="/customer/showproducts";
  customerchangepasswordurl:String='/customer/changepassword';
  showwishlisturl:string="/customer/showwishlist";
  getFeedback() {
   
  }
 
  feedback:FeedBack
  addfeedbackurl:string="/customer/addfeedback";
  constructor(private http:HttpClient) { }

  public getCustomer(id:String) {
    return this.http.get<Customer>(this.customerprofileurl+"/"+id);
  }
  public changepassword(id:String,newPassword:String,confirmPassword:String) {
    return this.http.get(this.customerchangepasswordurl+"/"+id+"/"+newPassword+"/"+confirmPassword);
  }
  getWishlist(){
    return this.http.get<WishList>(this.showwishlisturl+"/"+localStorage.getItem('token'));
}

addFeedBack(feedback:FeedBack) {

  return this.http.post(this.addfeedbackurl+"/"+1+"/"+13,feedback );
}

 
getProduct(){
  return this.http.get<Inventory[]>(this.urlshowproducts);
}

}
