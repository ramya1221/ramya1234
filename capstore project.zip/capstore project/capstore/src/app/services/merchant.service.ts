import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Inventory } from '../Model/inventory';
import { Merchant } from '../Model/merchant';

@Injectable({
  providedIn: 'root'
})
export class MerchantService {

  url:string='/merchant/addproduct';
  url2:string='/merchant/updateproduct';
  a:number=1;
  merchantprofileurl:String='/merchant/merchantprofile';
  merchantchangepasswordurl:String='/merchant/changepassword';

  constructor(private http:HttpClient) { }
 addProduct(inventory:Inventory){
   return this.http.post(this.url+"/"+this.a+"/"+inventory.productName+"/"+inventory.brand.brandName,inventory)
 }
 getById(productId:number){
  return this.http.get<Inventory>(this.url2+"/"+productId);
}
//getByQuantity(quantity:string){
 // return this.http.get<Inventory>(this.url+"/"+quantity);

updateInventory(inventory:Inventory){
 return this.http.put(this.url2+"/"+inventory.productId+"/"+inventory.price,inventory);
} 
/*updateQuantity(inventory:Inventory){
  return this.http.put(this.url+"/"+inventory.quantity,inventory);
 
 }*/ 
 public getMerchant(id:String) {
  return this.http.get<Merchant>(this.merchantprofileurl+"/"+id);
  }
  public changepassword(id:String,newPassword:String,confirmPassword:String) {
  return this.http.get(this.merchantchangepasswordurl+"/"+id+"/"+newPassword+"/"+confirmPassword);
  }  
  getProduct(id:string){
    return this.http.get<Inventory[]>(this.url+"/"+id);
}
 deleteProduct(product:Inventory){
 return this.http.delete<Inventory[]>(this.url+"/"+product.productId);
}

 
} 



