import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';


import { Key } from 'protractor';
import { Inventory } from '../../Model/inventory';
import { MerchantService } from '../../services/merchant.service';

@Component({
  selector: 'app-merchantshowproduct',
  templateUrl: './merchantshowproduct.component.html',
  styleUrls: ['./merchantshowproduct.component.css']
})
export class MerchantshowproductComponent implements OnInit {
  product:Inventory[];
  id:string;
  constructor(private merchantservice:MerchantService) { }

  ngOnInit() {
    this.merchantservice.getProduct(this.id).subscribe((data:Inventory[])=>{this.product=data
      console.log(this.product+""+this.merchantservice.getProduct.length)});
    this.id=JSON.parse(localStorage.getItem('token'));
    console.log(this.id);
    }
    deleteProduct(product:Inventory){
      console.log("Delete");
      this.merchantservice.deleteProduct(product).subscribe((data)=>{this.product=this.product.filter(p=>p!==product);
      });

  }

}
