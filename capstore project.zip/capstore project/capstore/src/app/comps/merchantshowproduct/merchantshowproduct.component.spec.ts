import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantshowproductComponent } from './merchantshowproduct.component';

describe('MerchantshowproductComponent', () => {
  let component: MerchantshowproductComponent;
  let fixture: ComponentFixture<MerchantshowproductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantshowproductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantshowproductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
