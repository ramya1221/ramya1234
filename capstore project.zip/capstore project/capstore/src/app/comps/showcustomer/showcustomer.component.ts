import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/Model/customer';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-showcustomer',
  templateUrl: './showcustomer.component.html',
  styleUrls: ['./showcustomer.component.css']
})
export class ShowcustomerComponent implements OnInit {
customers:Customer[];
  constructor(private adminService:AdminService) { }

  ngOnInit() {
    this.adminService.showCustomers().subscribe((data:Customer[])=>{
      this.customers=data;
    });
  }

}
