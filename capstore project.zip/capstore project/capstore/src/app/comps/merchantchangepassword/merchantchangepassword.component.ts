import { Component, OnInit } from '@angular/core';
import { Merchant } from '../../Model/merchant';
import { MerchantService } from '../../services/merchant.service';
import { Router, ActivatedRoute } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-merchantchangepassword',
  templateUrl: './merchantchangepassword.component.html',
  styleUrls: ['./merchantchangepassword.component.css']
})
export class MerchantchangepasswordComponent implements OnInit {
  id:string;
  password:string;
  oldPassword:string;
  newPassword:string;
  confirmPassword:string;
  status:string;
  merchant:Merchant;
 
  constructor(private merchantService:MerchantService, private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {  }

  onSubmit() {
 
     if(this.newPassword ==this.confirmPassword) {
      console.log(" New Passwords matched");
     }
      this.route.params.subscribe(
        (params)=>{
          this.merchantService.changepassword(params['id'],params['newPassword'],params['confirmPassword']);
                 });
     
       if(this.newPassword !=this.confirmPassword){
          console.log(" New Passwords  not matched");
        this.status = "Passwords  not matched ";
        }
        this.router.navigate(['merchantprofile']);
    }
  }


  
     

  


