import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../services/customer.service';
import { Customer } from '../../Model/customer';
import { Router, ActivatedRoute } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  id:string;
  password:string;
  oldPassword:string;
  newPassword:string;
  confirmPassword:string;
  status:string;
  customer:Customer;
 
  constructor(private  customerService:CustomerService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {  }

  onSubmit() {
   console.log("old: "+this.oldPassword);
   console.log("new: "+this.newPassword);
   console.log("confirm: "+this.confirmPassword);
   
     if(this.newPassword ==this.confirmPassword) {
    
      console.log(" New Passwords matched");
     }
      this.route.params.subscribe(
        (params)=>{
          this.customerService.changepassword(params['id'],params['newPassword'],params['confirmPassword']);
                 });
     
       if(this.newPassword !=this.confirmPassword){
          console.log(" New Passwords  not matched");
        this.status = "Passwords  not matched ";
        }
        this.router.navigate(['profile']);
    }
  }


  
     

  


