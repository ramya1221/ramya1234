import { Component, OnInit } from '@angular/core';
import { FeedBack } from 'src/app/Model/feed-back';
import { FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-add-feedbacks',

  templateUrl: './add-feedbacks.component.html',
  styleUrls: ['./add-feedbacks.component.css'],
  
})
export class AddFeedbacksComponent implements OnInit {
  
  feedBackData:FeedBack={"feedBackId":0,"customer":null,"inventory":null,"merchant":null,"ProductRating":0,"comments":'',"status":''}; 
  feedForm:FormGroup;
  constructor(private feedbackservice:CustomerService,private router:Router,private route:ActivatedRoute) { 

    
  }

  ngOnInit() {
  }
  onSubmit(){
    console.log("comments "+this.feedBackData.comments+"  ProductRating  "+this.feedBackData.ProductRating+"  status  "+this.feedBackData.status);
    
  this.route.params.subscribe((params)=>{this.feedbackservice.addFeedBack(params[' feedBackData']);}
  );
       
    this.feedbackservice.addFeedBack(this.feedBackData).subscribe((data)=>{this.router.navigate(['feedback']);
  });
  }
}
