import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-orders',
  templateUrl: './show-orders.component.html',
  styleUrls: ['./show-orders.component.css']
})
export class ShowOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
