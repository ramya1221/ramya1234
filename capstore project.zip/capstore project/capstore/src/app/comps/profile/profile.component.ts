import { Component, OnInit } from '@angular/core';
import { Customer } from '../../Model/customer';
import { Router, ActivatedRoute } from '../../../../node_modules/@angular/router';
import { CustomerService } from '../../services/customer.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  id:string;
  oldPassword:string;
  newPassword:string;
  confirmPassword:string;
  changePasswordForm;
  customerData:Customer={"customerId":0 ,"customerName":'',"phoneNumber":'',"emailId":'',"dateOfBirth":'',
  "password":'', "address":[], "lastLogin":'', "isActive":'', "shipping":null, "bank":null, 
  "managingCart":[], "order":[],"feedBack":[], "returnOrders":[], "wishList":[] }
  constructor(private customerService:CustomerService, private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    this.id =localStorage.getItem('token');
 // this.id = "hema@gmail.com";
       
       
        this.customerService.getCustomer(this.id).subscribe(
          (data)=>
          {
          this.customerData=data;
          });
        }
  
  }


