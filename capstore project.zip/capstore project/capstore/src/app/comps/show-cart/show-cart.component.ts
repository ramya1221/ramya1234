import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-cart',
  templateUrl: './show-cart.component.html',
  styleUrls: ['./show-cart.component.css']
})
export class ShowCartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
