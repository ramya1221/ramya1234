import { Component, OnInit } from '@angular/core';
import { Merchant } from 'src/app/Model/merchant';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-showmerchant',
  templateUrl: './showmerchant.component.html',
  styleUrls: ['./showmerchant.component.css']
})
export class ShowmerchantComponent implements OnInit {
  merchants:Merchant[];

  constructor(private adminService:AdminService) { }

  ngOnInit() {
    this.adminService.showMerchants().subscribe((data:Merchant[])=>{
      this.merchants=data;
    });
  }
  deleteMerchant(merchant:Merchant)
  {
    console.log("Delete");
    this.adminService.deleteMerchant(merchant).subscribe((data)=>{
      this.merchants=this.merchants.filter(m=>m!==merchant);
    });
  }
  approve(merchant:Merchant){
    console.log("approve");
    this.adminService.approve(merchant).subscribe((data)=>{
      this.merchants=this.merchants.filter(m=>m!==merchant);
    })
  }

}
