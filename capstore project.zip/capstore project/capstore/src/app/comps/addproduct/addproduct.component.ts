import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Inventory } from 'src/app/Model/inventory';
import { MerchantService } from 'src/app/services/merchant.service';
import { Brand } from 'src/app/Model/brand';
import { HomeComponent } from 'src/app/home/home.component';
import { Category } from 'src/app/Model/category';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
  brand:Brand;
  
  productData:Inventory={"productId":0,"productName":'',"description":'',"brand":null,"merchant":null,"noOfViews":0,
"category":null,"dateOfInclusion":'',"price":0,"quantity":0,"expiryDate":'',"managingCart":null,"discount":null,"coupon":null,"feedback":null,"wishList":null,"invoiceProduct":null};
 brandData:Brand={"brandId":0,"brandName":'',"inventory":null};
categoryData:Category={"categoryId":0,"categoryName":'',"dis":null,"inventory":null};
adminForm:FormGroup;
   
  constructor(private merchantservice:MerchantService,private router:Router) {
      
    }
  
    ngOnInit() {
    }
  onSubmit(){
    this.productData.brand=this.brandData;
    this.productData.category=this.categoryData;
    this.merchantservice.addProduct(this.productData).subscribe(
      (data)=>{this.router.navigate(['home']);
    }
      );
    
    }
  
  


  }


