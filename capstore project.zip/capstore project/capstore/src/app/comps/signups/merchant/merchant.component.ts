import { Component, OnInit } from '@angular/core';
import { Address } from 'src/app/Model/address';
import { Merchant } from 'src/app/Model/merchant';
import { SignupService } from 'src/app/services/signup.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-merchant',
  templateUrl: './merchant.component.html',
  styleUrls: ['./merchant.component.css']
})
export class MerchantComponent implements OnInit {
  addressData:Address={'streetNumber':0,'city':"",'country':"",'state':"",'zipcode':0,"shipping":null, "addressId":0,"customer":null,'merchant':null}
  merchantData:Merchant={'merchantId':"0",'merchantName':"",'status':"",'companyName':"capgemini","phoneNo":"",'emailId':"",'password':"",'isCertified':"yes",'isActive':"",'lastLogin':"",'address':null,'inventory':null,'feedback':null}
  constructor(private signupService:SignupService, private router:Router) { }

  ngOnInit() {
  }
  onSubmit() {
    this.merchantData.address[0]=this.addressData;
    console.log(this.merchantData.address);
    this.signupService.merchantSignup(this.merchantData).subscribe(data=>{
      this.router.navigate(['/merchanthome']);
    });
  }
}
