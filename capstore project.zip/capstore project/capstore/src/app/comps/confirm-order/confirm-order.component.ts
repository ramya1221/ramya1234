import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/services/customer.service';
import { Customer } from 'src/app/Model/customer';
import { Order } from 'src/app/Model/order';
import { Transaction } from 'src/app/Model/transaction';
import { GenerateInvoice } from 'src/app/Model/generate-invoice';
import { InvoiceProduct } from 'src/app/Model/invoice-product';
import { Inventory } from 'src/app/Model/inventory';
import { ManagingCart } from 'src/app/Model/managing-cart';
import { Coupons } from 'src/app/Model/coupons';
import { Discount } from 'src/app/Model/discount';

@Component({
  selector: 'app-confirm-order',
  templateUrl: './confirm-order.component.html',
  styleUrls: ['./confirm-order.component.css']
})
export class ConfirmOrderComponent implements OnInit {

  constructor(private customerService:CustomerService) { }
id:string;
customer:Customer;
orderList:Order[];
order:Order;
transaction:Transaction;
invoiceProduct:InvoiceProduct;
generateInvoice:GenerateInvoice;
inventory:Inventory;
managingCart:ManagingCart;
coupon:Coupons;
discount:Discount;
  ngOnInit() {
    this.id=localStorage.getItem('token');
    this.customerService.getCustomer(this.id).subscribe((data:Customer)=>{
    this.customer=data;
    this.orderList=this.customer.order;
    this.order=this.orderList.pop();
    this.transaction=this.order.transaction;
    this.generateInvoice = this.order.generateInvoice;
    this.invoiceProduct = this.order.generateInvoice.invoiceProduct;  
    this.inventory = this.invoiceProduct.inventory.pop();
    this.coupon = this.generateInvoice.coupon;
    this.discount = this.invoiceProduct.discount;
  });
  }

}
