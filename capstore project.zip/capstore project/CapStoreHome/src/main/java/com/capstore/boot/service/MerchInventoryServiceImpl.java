package com.capstore.boot.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.boot.dao.BrandDao;
import com.capstore.boot.dao.CategoryDao;
import com.capstore.boot.dao.IMerchDao;
import com.capstore.boot.dao.InventoryDao;
import com.capstore.boot.model.Brand;
import com.capstore.boot.model.Category;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;

@Service("inventoryServiceMerch")
@Transactional
public class MerchInventoryServiceImpl implements MerchInventoryService {
	@Autowired
	private InventoryDao inventoryDao;
	@Autowired
	private CategoryDao categoryDao;
	@Autowired
	private BrandDao brandDao;
	@Autowired
	private IMerchDao merchDao;
	@Autowired
	MerchantService merchantService;
	@Override
	public List<Inventory> getAllInventory() {
		
		List<Merchant> merchants = merchantService.getAllMerchant();
		List<Inventory> inventories = new ArrayList<Inventory>();
		for (Merchant merchant : merchants) {
			inventories.addAll(merchant.getInventory());
		}
		Set<Inventory> setInventories = new HashSet<Inventory>(inventories);
		List<Inventory> in=new ArrayList<Inventory>(setInventories);
		return in;
	
	}

	@Override
	public Inventory save(Inventory product) {

		return inventoryDao.save(product);
	}

	@Override
	public void delete(Integer productId) {

		// Inventory inventory = inventoryDao.findById(productId).get();

		inventoryDao.deleteProductbyId(productId);
	}

	@Override
	public List<Inventory> getAll() {
		return inventoryDao.findAll();
	}

	@Override
	public List<Brand> getAllBrands() {

		return brandDao.findAll();
	}

	@Override
	public List<Category> getAllCategories() {

		return categoryDao.findAll();
	}

	@Override
	public Merchant getMerch(int merchantId) {

		return merchDao.getOne(merchantId);
	}

	@Override
	public List<Merchant> getAllMerch() {

		return merchDao.findAll();
	}

	@Override
	public Inventory getProduct(String productName) {
		return inventoryDao.findOne(productName);
	}

	@Override
	public Merchant addProduct(Merchant merchant) {

		return merchDao.save(merchant);
	}

	@Override
	public Category getCategoryByName(String categoryName) {
		return categoryDao.findByCategoryName(categoryName);
	}

	@Override
	public Inventory getById(Integer productid) {

		return inventoryDao.findById(productid).get();
	}

	@Override
	public List<Inventory> getMerchantInventory(Integer merchantid) {
		Merchant merchant = merchDao.findById(merchantid).get();
		List<Inventory> inventories = merchant.getInventory();
		return inventories;
	}

	@Transactional
	@Override
	public Inventory updateProduct(Inventory inventory) {
		return inventoryDao.save(inventory);
	}

}
