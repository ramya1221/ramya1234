package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Address;
import com.capstore.boot.model.Customer;
import com.capstore.boot.model.ManagingCart;
import com.capstore.boot.model.WishList;



public interface CustomerService {

	public List<Customer> getAllCustomerEmail();
	
	Customer findOne(Integer customerId);

	List<Customer> getAllCustomer();
	public List<Customer> getAllCustomers();

	public Customer findByEmailId(String emailId);

	public boolean createcustomer(Customer customer);

	public String encrypt(String str);
	
	public String decrypt(String str);
	
	//public Customer validateCustomer(String email);
	
	public ManagingCart addToCart(ManagingCart managingCart);
	
	public Customer findCustomerByEmailId(String emailId);

	public List<Address> createAddress(Address address,int customerId);

	public Customer updatecustomer(Customer customer);

	public WishList addToWishList(WishList wishList);

	
	
}
