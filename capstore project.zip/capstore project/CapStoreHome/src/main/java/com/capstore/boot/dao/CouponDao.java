package com.capstore.boot.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.boot.model.Coupons;

public interface CouponDao extends JpaRepository<Coupons, Integer> {

	Coupons findByCouponCode(String couponcode);

}
