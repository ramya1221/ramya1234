package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Brand;
import com.capstore.boot.model.Category;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;

public interface MerchInventoryService {

	public Inventory save(Inventory product);

	public void delete(Integer productId);

	public List<Inventory> getAll();

	List<Inventory> getAllInventory();

	public List<Brand> getAllBrands();

	public List<Category> getAllCategories();

	public Merchant getMerch(int merchantId);

	public List<Merchant> getAllMerch();

	public Inventory getProduct(String productName);

	public Merchant addProduct(Merchant merchant);

	public Category getCategoryByName(String categoryName);

	public Inventory getById(Integer productid);

	// void delete(Integer productId, String productname);
	public List<Inventory> getMerchantInventory(Integer merchantid);

	public Inventory updateProduct(Inventory inventory);

}
