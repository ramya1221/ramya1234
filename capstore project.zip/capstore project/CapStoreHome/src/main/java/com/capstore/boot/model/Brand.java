package com.capstore.boot.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Component
@Table(name = "capbrand")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Brand implements Serializable{
	@Id
	@GeneratedValue(generator = "cust1", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "cust1", sequenceName = "capbrandseq", initialValue = 1, allocationSize = 1)
	private int brandId;
	private String brandName;
	@JsonIgnore
	@OneToMany(targetEntity = Inventory.class, mappedBy = "brand")
	private List<Inventory> inventory;

	public Brand() {
		super();
		System.out.println("brand");
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public List<Inventory> getInventory() {
		return inventory;
	}

	public void setInventory(List<Inventory> inventory) {
		this.inventory = inventory;
	}

	public Brand(int brandId, String brandName, List<Inventory> inventory) {
		super();
		this.brandId = brandId;
		this.brandName = brandName;
		this.inventory = inventory;
	}

	/*
	 * @Override public String toString() { return "Brand [brandId=" + brandId +
	 * ", brandName=" + brandName + ", inventory=" + inventory + "]"; }
	 */
}