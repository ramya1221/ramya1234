package com.capstore.boot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.boot.model.Inventory;

@Repository("inventoryDao")


public interface InventoryDao extends JpaRepository<Inventory, Integer>{
	
	@Query("select i from Inventory i where i.productName=:product")
	Inventory findOne(@Param("product") String product);
	
	List<Inventory> findByproductName(String name);

	

	@Transactional
	@Modifying
	@Query("delete from Inventory i where i.productId=:productId")
	public void deleteProductbyId(Integer productId);
	
	
	/*@Query("select from Inventory i where i.merchant_id=:id")
	List<Inventory> getInventoryByMerchantId(int id);*/
	
	
	
	
	
}
