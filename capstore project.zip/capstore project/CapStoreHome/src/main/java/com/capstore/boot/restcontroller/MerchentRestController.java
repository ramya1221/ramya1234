package com.capstore.boot.restcontroller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.boot.dao.DiscountDao;
import com.capstore.boot.dao.InventoryDao;
import com.capstore.boot.model.Address;
import com.capstore.boot.model.Brand;
import com.capstore.boot.model.Category;
import com.capstore.boot.model.Coupons;
import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Discount;
import com.capstore.boot.model.FeedBack;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.service.IFeedbackService;
import com.capstore.boot.service.InventoryService;
import com.capstore.boot.service.MerchInventoryService;
import com.capstore.boot.service.MerchantService;

//@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/merchant")
@RestController
public class MerchentRestController {

	@Autowired
	MerchantService merchantService;

	@Autowired
	MerchInventoryService merchInventoryService;

	@Autowired
	DiscountDao discountdao;

	@Autowired
	InventoryService inventoryService;

	@Autowired
	IFeedbackService iFeedbackService;

	@PostMapping("/addmerchant")
	public boolean addMerchant(@RequestBody Merchant merchant) {
		return merchantService.saveMerchant(merchant);
	}

	@GetMapping("/loginmerchant/{id}")
	public Merchant validateMerchant(@PathVariable String id) {
		// String encryptedPassword = merchantService.encrypt(password);
		Merchant merchant = merchantService.validateMerchant(id);
		return merchantService.validateMerchant(id);
	}

	@PostMapping("/addproduct/{merchantId}/{producttype}/{productbrand}")
	public void addProduct(@PathVariable int merchantId, @PathVariable String producttype,
			@PathVariable String productbrand, @RequestBody Inventory inventory) {
		List<Inventory> inventories = new ArrayList<Inventory>();
		List<Inventory> inventcategories;

		Brand brand = new Brand();

		// category code
		Category category = merchInventoryService.getCategoryByName(producttype);

		if (category == null) {
			category = new Category();
			inventcategories = new ArrayList<Inventory>();
			category.setCategoryName(producttype);
			System.out.println(category);
		}

		else
			inventcategories = category.getInventory();
		inventcategories.add(inventory);
		category.setInventory(inventcategories);

		inventory.setCategory(category);

		Merchant merchant = merchantService.findMerchantById(merchantId);

		inventory.setMerchant(merchant);

		if (merchant.getInventory() != null)
			inventories = merchant.getInventory();

		// brand.setInventory(inventories);
		brand.setBrandName(productbrand);
		inventory.setBrand(brand);

		inventories.add(inventory);
		merchant.setInventory(inventories);

		merchInventoryService.addProduct(merchant);
	}

	@GetMapping("/showproducts/{merchantid}")
	public List<Inventory> showProducts(@PathVariable Integer merchantid) {
		return merchInventoryService.getMerchantInventory(merchantid);
	}

	@GetMapping("/showproductbyid/{productid}")
	public Inventory showProductById(@PathVariable Integer productid) {
		return inventoryService.getProductByid(productid);
	}

	@DeleteMapping("/deleteproduct/{productid}")
	public boolean deleteProduct(@PathVariable Integer productid) {

		merchInventoryService.delete(productid);
		return true;
	}

	@PutMapping("/updatemerchant/{merchid}")
	public Merchant updateMerchant(@RequestBody Merchant merchant, @PathVariable Integer merchid) {
		merchant.setMerchantId(merchid);
		return merchantService.updateMerchant(merchant);
	}

	@PutMapping("/updateproduct/{productid}")
	public Inventory updateProduct(@RequestBody Inventory inventory, @PathVariable Integer productid) {
		inventory.setProductId(productid);
		return merchInventoryService.updateProduct(inventory);
	}

	@GetMapping("/merchantprofile/{merchantemail}")
	public Merchant showCustomerById(@PathVariable String merchantemail) {
		return merchantService.findByMerchantEmail(merchantemail);
	}

	@PostMapping("/changepassword/{merchantid}/{newpassword}/{confirmpassword}")
	public Merchant changePassword(@PathVariable Integer merchantid, @PathVariable String newpassword,
			@PathVariable String confirmpassword) {
		Merchant merchant = merchantService.findMerchantById(merchantid);
		String oldpassword = merchant.getPassword();
		Merchant updatedmerchant = merchant;
		if (newpassword.equals(confirmpassword)) {
			if (oldpassword.equals(newpassword)) {
			} else {
				merchant.setPassword(newpassword);
				updatedmerchant = merchantService.updateMerchant(merchant);
			}
		}
		return updatedmerchant;

	}

	@PostMapping("/adddiscount/{merchantid}/{productid}")
	public Discount AddDiscount(@PathVariable Integer merchantid, @PathVariable Integer productid,
			@RequestBody Discount discount) {
		Inventory inventory = null;

		Merchant merchant = merchantService.findMerchantById(merchantid);
		List<Inventory> inventories = merchant.getInventory();
		Discount discount2 = new Discount();
		if (inventories != null) {

			for (Inventory i : inventories) {
				if (i.getProductId() == productid) {
					inventory = i;
					break;
				}
			}
		}
		discount2 = discount;
		inventory.setDiscount(discount2);
		discount2.setInventory(inventory);

		return discountdao.save(discount2);
	}

	@GetMapping("/showdiscount/{productid}")
	public double applyDiscount(@PathVariable Integer productid) {
		Inventory inventory = inventoryService.getProductByid(productid);
		Discount discount = inventory.getDiscount();
		double amount = discount.getPromoAmount();
		return amount;
	}

	@PostMapping("/addaddress/{merchantid}")
	public void addAddress(@PathVariable Integer merchantid, @RequestBody Address address) {

		merchantService.createAddress(address, merchantid);
	}

	@PostMapping("/addfeedback/{merchantid}/{productid}")
	public FeedBack addFeedback(@RequestBody FeedBack feedback, @PathVariable Integer merchantid,
			@PathVariable Integer productid) {
		Inventory inventory = inventoryService.getProductByid(productid);
		// Merchant customer = merchantService.findMerchantById(merchantid);
		Merchant merchant = inventory.getMerchant();

		List<FeedBack> productFeedback = inventory.getFeedback();
		if (productFeedback == null)
			productFeedback = new ArrayList<FeedBack>();
		productFeedback.add(feedback);

		List<FeedBack> productMerchantFeedback = merchant.getFeedback();
		if (productMerchantFeedback == null)
			productMerchantFeedback = new ArrayList<FeedBack>();
		productMerchantFeedback.add(feedback);

		inventory.setFeedback(productFeedback);
		List<Inventory> inventories = merchant.getInventory();
		inventories.add(inventory);
		merchant.setInventory(inventories);
		merchant.setFeedback(productMerchantFeedback);
		feedback.setInventory(inventory);
		feedback.setMerchant(merchant);

		// feedback.setCustomer(merchant);
		return iFeedbackService.createFeedback(feedback);
	}

}
