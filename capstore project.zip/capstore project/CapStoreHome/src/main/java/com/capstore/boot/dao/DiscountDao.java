package com.capstore.boot.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.boot.model.Discount;

public interface DiscountDao extends JpaRepository<Discount, Integer> {

}
