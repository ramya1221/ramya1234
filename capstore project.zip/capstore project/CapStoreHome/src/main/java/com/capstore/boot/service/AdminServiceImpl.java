package com.capstore.boot.service;

import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.AdminDao;
import com.capstore.boot.dao.CouponDao;
import com.capstore.boot.model.Admin;
import com.capstore.boot.model.Coupons;
import com.capstore.boot.model.Merchant;

@Service("adminService")
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminDao adminDao;
	@Autowired
	CouponDao couponDao;
	@Override
	public List<Admin> getAdminEmail() {
		return adminDao.findAll();
	}

	@Override
	public Admin validateAdmin(Integer id) {
		return adminDao.findAdminById(id);
	}

	public String encrypt(String str) {
		// Getting encoder
		Base64.Encoder encoder = Base64.getEncoder();
		// encrypted String
		String ecode = encoder.encodeToString(str.getBytes());
		return ecode;
	}

	public String decrypt(String str) {
		// Getting encoder
		Base64.Decoder decoder = Base64.getDecoder();
		// encrypted String
		byte[] ecode = decoder.decode(str);
		return new String(ecode);
	}

	@Override
	public void createCoupon(Coupons coupon) {
		couponDao.save(coupon);
		
	}


}
