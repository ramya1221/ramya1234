package com.capstore.boot.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.BrandDao;
import com.capstore.boot.dao.CategoryDao;
import com.capstore.boot.dao.InventoryDao;
import com.capstore.boot.model.Brand;
import com.capstore.boot.model.Category;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;

@Service("inventoryService")
@Transactional
public class InventoryServiceImpl implements InventoryService {
	@Autowired
	InventoryDao inventoryDao;

	@Autowired
	private BrandDao brandDao;

	@Autowired
	private CategoryDao categoryDao;
	
	@Autowired
	MerchantService merchantService;

	@Override
	public List<Inventory> getAllInventory() {
		List<Merchant> merchants = merchantService.getAllMerchant();
		List<Inventory> inventories = new ArrayList<Inventory>();
		for (Merchant merchant : merchants) {
			inventories.addAll(merchant.getInventory());
		}
		Set<Inventory> setInventories = new HashSet<Inventory>(inventories);
		List<Inventory> newinventories=new ArrayList<Inventory>(setInventories);
		return newinventories;
		//return (List<Inventory>) inventoryDao.findAll();
	}

	@Override
	public Inventory saveInventory(Inventory product) {
		return inventoryDao.save(product);
	}

	@Override
	public void delete(Integer productId) {
		
		inventoryDao.deleteById(productId);
	}

	@Override
	public List<Inventory> getAll() {
		
		return inventoryDao.findAll();
	}

	@Override
	public List<Brand> getAllBrands() {
		
		return brandDao.findAll();
	}

	@Override
	public List<Category> getAllCategories() {

		return categoryDao.findAll();
	}

	@Override
	public List<Inventory> getInventoryByName(String inventoryName) {

		return inventoryDao.findByproductName(inventoryName);
	}

	@Override
	public Inventory getProductByid(int pid) {

		return inventoryDao.getOne(pid);
	}

}
