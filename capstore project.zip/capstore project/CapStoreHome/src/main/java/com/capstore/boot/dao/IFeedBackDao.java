package com.capstore.boot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstore.boot.model.FeedBack;





@Repository("iFeedBackRepo")
public interface IFeedBackDao extends JpaRepository<FeedBack, String>
{

     
}
