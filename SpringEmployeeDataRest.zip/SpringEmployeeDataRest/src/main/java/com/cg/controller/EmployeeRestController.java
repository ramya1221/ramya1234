package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Employee;
import com.cg.serive.EmployeeService;


@RestController
public class EmployeeRestController {
	
	@Autowired
	EmployeeService employeeService;
	@Autowired
	Employee employee;
	@PostMapping("/add/{name}/{address}/{salary}/{designation}")
	public Employee addEmployee(@PathVariable String name,@PathVariable String address,
			@PathVariable Double salary,@PathVariable String designation) {
		employee.setName(name);
		employee.setAddress(address);
		employee.setSalary(salary);
		employee.setDesignation(designation);
		Employee savedEmp=employeeService.addEmployee(employee);
		return savedEmp;
	}
	
	
	@PostMapping(value="/addobject",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Employee addEmpObject(@RequestBody Employee employee) {
		Employee savedEmp=employeeService.addEmployee(employee);
		return savedEmp;
	}
	

	@GetMapping("/viewall")//should type in postman
	public List<Employee> viewAll(){
	return employeeService.getEmployees();
}
    //get
	//http://localhost:8085/viewaddress?address=hyderabad
	@GetMapping("/viewaddress")
	public List<Employee> viewAddress(@RequestParam String address){
		return employeeService.getEmployeesByAddress(address);
	}
	
	
	//get
	//http://localhost:8085/viewaddress/hyderabad
	@GetMapping("/viewaddress/{address}")
	public List<Employee> viewAddressPath(@PathVariable String address){
		return employeeService.getEmployeesByAddress(address);
	}
	
	//get
	///http://localhost:8085/viewdesignation?designation=trainer
	
	@GetMapping("/viewdesignation")
	public List<Employee> viewDesignation(@RequestParam String designation){
		return employeeService.getEmployeesByDesignation(designation);
	}
	//get
	///http://localhost:8085/viewdesignation/trainer
	@GetMapping("/viewdesignation/{designation}")
	public List<Employee> viewDesignationPath(@PathVariable String designation){
		return employeeService.getEmployeesByDesignation(designation);
	}
	
	
	//delete
	//http://localhost:8085/deletebyid/3005
	@DeleteMapping("/deletebyid/{empId}")
	public String deletebyId(@PathVariable Integer empId) {
		employeeService.deleteById(empId);
		return empId+" deleted";
	}
	
	
	//delete
	//http://localhost:8085/deleteall
	@GetMapping("/deleteall/{empId}")
	public void deleteall() {
		employeeService.deleteAll();
	}
	
	//get
	//http://localhost:8085/findbyid/3006
	@GetMapping("/findbyid/{empId}")
	public Employee findbyId(@PathVariable Integer empId) {
		return employeeService.findById(empId);
	}
	//get
	//http://localhost:8085/salaryrange/10000/300000
	@GetMapping("/salaryrange/{salary1}/{salary2}")
	public List<Employee> salaryRange(@PathVariable Double salary1,@PathVariable Double salary2){
		return employeeService.salaryRange(salary1, salary2);
	}
	
	
	
	//get
	//http://localhost:8085/salaryrange?salary1=20000&salary2=300000
	@GetMapping("/salaryrange")
	public List<Employee> salaryRangeParam(@RequestParam Double salary1,@RequestParam Double salary2){
		return employeeService.salaryRange(salary1, salary2);
	}
	
	
	//put
	//http://localhost:8083/updateobject send complete json
	@PutMapping(value="/updateobject",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Employee updateEmpObject(@RequestBody Employee employee) {
		Employee updatedEmp=employeeService.updateEmployee(employee);
		return updatedEmp;
	}
	
}
